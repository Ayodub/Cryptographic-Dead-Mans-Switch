import glob
import os
# Encryption/decryption buffer size - 64K
bufferSize = 64 * 1024
# Get current directory
currentdirectory = os.getcwd()
# Prompt user for password to encrypt files
password1 = input('\n> Enter password to encrypt: ')
 
print('\n> Beginning recursive encryption...\n\n')
# Main loop to encrypt all files recursively
for x in glob.glob('./test', recursive=True):
    fullpath = os.path.join(currentdirectory, x)
    fullnewf = os.path.join(currentdirectory, x + '.aes')
    # Encrypt
    if os.path.isfile(fullpath):
        print('>>> Original: \t' + fullpath + '')
        print('>>> Encrypted: \t' + fullnewf + '\n')
        pyAesCrypt.encryptFile(fullpath, fullnewf, password1, bufferSize)
        # Remove file after encryption
        #os.remove(fullpath)
